

<br><br><br><br><br>

<!-- Section untuk menampilkan kategori produk -->
<section class="store-trend-categories">
  <div class="container">
      <div class="row">

        <!-- Judul untuk kategori -->
          <div class="col-12" data-aos="fade-up">
              <h5>Categories</h5>
          </div>
      </div>
      <div class="row">
        <!-- Menampilkan setiap kategori -->
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-6 col-md-3 col-lg-2" data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 100); ?>">
                  <a class="component-categories d-block" href="<?php echo e(route('products.byCategory', ['id' => $category->id])); ?>">
                      <div class="categories-image">
                          <img
                              src="/images/categories-<?php echo e(strtolower($category->name)); ?>.svg"
                              alt="<?php echo e($category->name); ?> Categories"
                              class="w-100"
                          />
                      </div>
                      <p class="categories-text">
                          <?php echo e($category->name); ?>

                      </p>
                  </a>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>
</section>

    
    <!-- Bagian untuk menampilkan produk -->
    <section class="store-new-products">
        <div class="container">
            <div class="row">
                <div class="col-12" data-aos="fade-up">
                    <h5>All Products</h5>
                </div>
            </div>
            <div class="row">

                <!-- Menampilkan setiap produk -->
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="<?php echo e($loop->iteration * 100); ?>">
                    <div class="product">
                        <img src="<?php echo e(asset($product->image_url)); ?>" alt="<?php echo e($product->name); ?>" class="w-100">
                        <p><?php echo e($product->name); ?></p>
                        <p>Rp.<?php echo e(number_format($product->price, 0, ',', '.')); ?></p>

                        <!-- Form untuk menambahkan produk ke keranjang -->
                        <form method="POST" action="<?php echo e(route('cart.add')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <button type="submit" class="btn btn-success">Add to Cart</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php echo $__env->make('layouts.mainsuccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kerja\tajoki\flutter\pasar-kuliah\backend\Frontend-Backend_PasarKuliah\resources\views/categories.blade.php ENDPATH**/ ?>