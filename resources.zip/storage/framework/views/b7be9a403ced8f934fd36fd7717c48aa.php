

   <!-- Page Content -->
   <br>
   <div class="page-content page-auth">
    <!-- auth -->
    <div class="section-store-auth" data-aos="fade-up">
      <div class="container">
        <div class="row align-items-center row-login">
          <div class="col-lg-6 text-center">
            <img
              src="/images/login-placeholder.png"
              alt=""
              class="w-50 mb-4 mb-lg-none"
            />
          </div>
          <div class="col-lg-5">
            <h2>
              Belanja kebutuhan Perkuliahan, <br />
              menjadi lebih mudah
            </h2>

            <!-- Form login -->
            <form class="mt-3" action="<?php echo e(route('login.post')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                  <label for="email">Email:</label>
                  <input type="email" name="email" id="email" class="form-control w-75" required value="<?php echo e(old('email')); ?>">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <!-- Menampilkan pesan error jika terjadi kesalahan validasi pada email -->
                  <div class="alert alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                  <label for="password">Password:</label>
                  <input type="password" name="password" id="password" class="form-control w-75" required>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <!-- Tombol login -->
              <button type="submit" class="btn btn-success btn-block w-75 mt-4">Login</button>
              <!-- Tautan untuk menuju halaman register -->
              <a class="btn btn-signup w-75 mt-2" href="/register.html">
                Register
              </a>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kerja\tajoki\flutter\pasar-kuliah\backend\Frontend-Backend_PasarKuliah\resources\views/login/index.blade.php ENDPATH**/ ?>