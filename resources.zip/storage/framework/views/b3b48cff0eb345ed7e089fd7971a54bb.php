

<br><br><br><br><br>
<div class="container">
    <!-- Judul untuk halaman keranjang belanja -->
    <h2>Shopping Cart</h2>
    <hr>

    <!-- Tabel untuk menampilkan item dalam keranjang -->
    <table class="table table-borderless table-cart">
        <thead>
            <tr>
                <th scope="col">Image</th>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Quantity</th>
                <th scope="col">Edit</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <!-- Menampilkan gambar produk -->
                <td><img src="<?php echo e($item->product->image_url); ?>" alt="<?php echo e($item->product->name); ?>" width="100"></td>
                
                <!-- Menampilkan nama produk -->
                <td><?php echo e($item->product->name); ?></td>

                <!-- Menampilkan harga produk -->
                <td><?php echo e($item->product->price); ?></td>
                
                <td>
                    <!-- Form untuk mengatur kuantitas -->
                    <form action="<?php echo e(route('cart.update', ['id' => $item->product->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <!-- Tombol Kurang -->
                        <button type="submit" name="action" value="decrease" class="btn btn-warning">-</button>
                        <!-- Menampilkan jumlah saat ini -->
                        <span><?php echo e($item->quantity); ?></span>
                        <!-- Tombol Tambah -->
                        <button type="submit" name="action" value="increase" class="btn btn-success">+</button>
                    </form>
                </td>
                <td>
                    <!-- Tombol untuk menghapus item dari keranjang -->
                    <form action="<?php echo e(route('cart.remove', ['id' => $item->product->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Menampilkan total harga dan tombol checkout -->
    <div>
        <p>Total Price: <?php echo e($totalPrice); ?></p>
        <!-- Tombol untuk menuju halaman checkout -->
        <div class="mt-3">
            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Checkout</a>
        </div>      
    </div>
</div>

<?php echo $__env->make('layouts.mainsuccess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kerja\tajoki\flutter\pasar-kuliah\backend\Frontend-Backend_PasarKuliah\resources\views/cart/show.blade.php ENDPATH**/ ?>