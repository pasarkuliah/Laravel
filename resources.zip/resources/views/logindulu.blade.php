@extends('layouts.main')

<!-- peringatan supaya user harus login dulu untuk dapat mengakses -->
<br><br><br><br><br><br><br><br><br><br>
<h1>
    --------------------login dulu----------------------
</h1>

<br><br>